document.addEventListener('DOMContentLoaded', function () {
    const calendarEl = document.getElementById('calendar');
    let currentYear, currentMonth; // Variables to store current month and year
    let isPastMonth = false;

    function fetchEventsAndRender(year, month, isPastMonth = false) {
        fetch(`/user/events?year=${year}&month=${month}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(response => {
                if (response.status) {
                    const eventsJson = response.data;

                    const calendar = new FullCalendar.Calendar(calendarEl, {
                        initialDate: new Date(year, month - 1),
                        editable: true,
                        selectable: true,
                        businessHours: true,
                        dayMaxEvents: true,
                        events: eventsJson.map(event => ({
                            ...event,
                            color: isPastMonth ? '#f32e75' : "#86cb05",
                            textColor:  'white'

                        })),
                        datesSet: function (info) {
                            const view = calendar.view;
                            let newYear = view.currentStart.getFullYear();
                            let newMonth = view.currentStart.getMonth() + 1;
                            if (newYear !== currentYear || newMonth !== currentMonth) {
                                currentYear = newYear;
                                currentMonth = newMonth;
                                isPastMonth = view.currentStart < new Date() ?? true;
                                fetchEventsAndRender(currentYear, currentMonth, isPastMonth);
                            }
                        }
                    });
                    calendar.render();
                } else {
                }


            })
            .catch(error => {
                console.error(error);
            });
    }

    // Fetch events for the current month by default
    const currentDate = new Date();
    currentYear = currentDate.getFullYear();
    currentMonth = currentDate.getMonth() + 1; // Month index starts from 0
    fetchEventsAndRender(currentYear, currentMonth);
});
