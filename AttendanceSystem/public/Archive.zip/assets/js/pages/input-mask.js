$(document).ready(function() {
    
    "use strict";
    $("#inputMask1").inputmask();
    $("#inputMask2").inputmask();
    $("#inputMask3").inputmask();
    $("#inputMask4").inputmask();
});