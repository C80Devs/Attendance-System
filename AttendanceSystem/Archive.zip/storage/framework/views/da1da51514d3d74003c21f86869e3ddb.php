

<div class="row mt-4 mb-4">
    <div>
        <!--[if BLOCK]><![endif]--><?php if(session()->has('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <?php if(session()->has('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    <div class="col">
        <div class="card border-light text-center">
            <div class="card-header">
                Current Time
            </div>
            <div class="card-body mb-4">
                <h1 class=" mt-2 mb-4" id="current-time"><?php echo e(now()->format('h:i:s A')); ?></h1>
                <!--[if BLOCK]><![endif]--><?php if($clockedIn): ?>
                    <button id="clock-button" wire:click="clock(latitude, longitude)" class="btn btn-danger mb-4"><i
                            class="bi bi-clock text-center"></i>
                        Clock Out
                    </button>

                    <p class="alert-success text-muted pt-2 pb-4"><i class="bi bi-clock"></i> You clocked in
                        at <?php echo e($clockInTime); ?>!</p>


                <?php elseif($clockedOut): ?>
                    <p class="text-muted"><i class="bi bi-clock"></i> Complete for today!</p>
                    <p class="alert-warning text-muted pt-2 pb-4"><i class="bi bi-clock"></i> You clocked out at <?php echo e($clockOutTime); ?>!</p>

                <?php else: ?>
                    <button id="clock-button" wire:click="clock(latitude, longitude)" class="btn primaryButton"><i
                            class="bi bi-clock text-center"></i>
                        Clock In
                    </button>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <div id="location_alert" class="alert alert-warning mt-4" style="display: none;">Turn on location.</div>
            </div>
            <div class="card-footer text-muted">
               <div class="row align-items-center">
                   <div class="row mb-2">
                       <i class="material-icons">location_on</i>
                   </div>
                   <div class="row text-center">
                       <p>                       <?php echo e(now()->timezoneName); ?>

                       </p>

                   </div>
               </div>
            </div>


        </div>
    </div>


</div>
<script>
    let latitude;
    let longitude;
</script>

<script>

    let location_alert = document.getElementById("location_alert");
    let locationRetrieved = false;

    let clock_button = document.getElementById("clock-button");
    setInterval(updateTime, 1000);
    let locationInterval = setInterval(getLocationAndClock, 1000);

    function getLocationAndClock() {
        if (locationRetrieved) {
            clearInterval(locationInterval);
        }
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function (position) {
                locationRetrieved = true;
                latitude = position.coords.latitude;
                longitude = position.coords.longitude;
                // Set flag to true after successful retrieval
                enableClockButton();

            }, function (error) {
                console.error('Error getting location:', error);
                disableClockButton();
            });
        } else {
            console.error('Geolocation is not supported by this browser.');
            disableClockButton();
        }
    }

    function updateTime() {
        document.getElementById('current-time').innerText = new Date().toLocaleTimeString('en-US', {
            hour: 'numeric',
            minute: 'numeric',
            second: 'numeric',
            hour12: true
        });
    }

    function disableClockButton() {
        clock_button.style.display = 'none';
        location_alert.style.display = 'block';
    }

    function enableClockButton() {
        clock_button.style.display = 'inline';
        location_alert.style.display = 'none';
    }
</script>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Attendance System/AttendanceSystem/resources/views/livewire/clocker.blade.php ENDPATH**/ ?>