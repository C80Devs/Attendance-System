<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('header-calendar');

$__html = app('livewire')->mount($__name, $__params, 'lw-3542158067-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

<div class="container">
    <div class="row justify-content-center mt-4">
        <div class="col-md-6">
            <?php if($attendance->isEmpty()): ?>
                <div class="alert alert-secondary text-center" role="alert">
                    No Attendance record found!
                </div>
            <?php else: ?>
                <div class="container-fluid">
                    <div class="row mt-4">
                        <div class="col">
                            <div class="card-title text-center text-muted">Attendance Activity (<?php echo e($count); ?>)</div>
                            <hr class="text-muted mb-4">

                            <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-12">
                                        <p class="text-muted mb-2"><?php echo e($attend->clockInHeader); ?></p>
                                        <div class="card bg-white border-0 text-muted justify-content-center pb-4 pt-4"
                                             style="height: 60px">
                                            <div class="row align-items-center">
                                                <div class="col-4 text-center">
                                                    <i class="material-icons text-success">schedule</i>
                                                    <div class="row align-items-center d-flex">
                                                        <a style="font-size: 10px" class="align-items-center"
                                                           href="<?php echo e($attend->clockin_location); ?>">
                                                            View Location </a>

                                                    </div>
                                                </div>
                                                <div class="col-4 text-center">
                                                    Clock In
                                                </div>
                                                <div class="col-4 text-center">
                                                    <?php echo e($attend->clockIn); ?>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="card bg-white border-0 text-muted justify-content-center mt-4 mb-4"
                                             style="height: 60px">
                                            <div class="row align-items-center">
                                                <div class="col-4 text-center">
                                                    <i class="material-icons text-danger">schedule</i>
                                                    <div class="row align-items-center d-flex">
                                                        <a style="font-size: 10px" class="align-items-center"
                                                           href="<?php echo e($attend->clockin_location); ?>">
                                                            View Location </a>

                                                    </div>
                                                </div>
                                                <div class="col-4 text-center">
                                                    Clock Out
                                                </div>
                                                <div class="col-4 text-center">
                                                    <?php echo e($attend->clockOut); ?>

                                                </div>
                                            </div>
                                        </div>
                                        <hr class="mb-2">
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <!-- Tailwind Pagination Links -->
                            <div class="mt-4 flex justify-center">
                                <?php echo e($attendance->links('vendor.tailwind')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Attendance System/AttendanceSystem/resources/views/activity.blade.php ENDPATH**/ ?>