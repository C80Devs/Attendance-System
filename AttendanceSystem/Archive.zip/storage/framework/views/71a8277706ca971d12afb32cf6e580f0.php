<div class="container-fluid">
    <div class="row mt-4">
        <div class="col">
            <div class="d-flex">
                <?php
                    $currentDate = now()->startOfDay();
                ?>
                <!--[if BLOCK]><![endif]--><?php for($i = 0; $i < 6; $i++): ?>
                    <?php
                        $date = $currentDate->copy()->addDays($i);
                        $isToday = $date->isToday();
                    ?>
                    <div class="card <?php echo e($isToday ? 'bgPrimary ' : ''); ?> m-2" style="width: calc(100% / 6);">
                        <div class="card-body p-2 hover-overlay">
                            <p class="card-subtitle text-center pt-2 <?php echo e($isToday ? 'text-white ' : 'text-muted'); ?>"><?php echo e($date->format('D')); ?></p>
                            <h6 class="card-subtitle mb-2 <?php echo e($isToday ? 'text-white ' : 'text-muted'); ?> text-center"><?php echo e($date->format('d')); ?></h6>
                        </div>
                    </div>
                <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </div>

</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Attendance System/AttendanceSystem/resources/views/livewire/header-calendar.blade.php ENDPATH**/ ?>