<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('header-calendar');

$__html = app('livewire')->mount($__name, $__params, 'lw-331348223-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <div class="row mt-4">
        <div class="col">
            <div id="location-prompt" class="alert alert-warning" style="display: none;">
                Please enable location services to use the clock feature.
            </div>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('Clocker', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-331348223-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>

<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Attendance System/AttendanceSystem/resources/views/dashboard.blade.php ENDPATH**/ ?>