<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/perfectscroll/perfect-scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/pace/pace.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/highlight/highlight.pack.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/fullcalendar/lib/main.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/main.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/datatables.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/calendar.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/select2/js/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/settings.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/summernote/summernote-lite.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/mailbox.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/flatpickr/flatpickr.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/datepickers.js')); ?>"></script>

<!-- Moment.js library -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
<!-- Bootstrap DateTimePicker library -->
<script
    src="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.39.0/js/tempusdominus-bootstrap-4.min.js"></script>



<script
    src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<link
    href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css"
    rel="stylesheet"/>

<!-- Toastr JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.14.0/Sortable.min.js"></script>


<script>
    // Initialize Toastr options
    toastr.options = {
        "closeButton": true,
        "debug": false,
        "newestOnTop": true,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "preventDuplicates": true,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "2000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }


        <?php if(session('success')): ?>
        toastr.success("<?php echo e(session('success')); ?>");
       <?php endif; ?>

       <?php if(session('error')): ?>
       toastr.success("<?php echo e(session('error')); ?>");
    <?php endif; ?>


</script>

<script>
    $(document).ready(function () {
        $('[data-toggle="tooltip"]').tooltip();

        Livewire.on('alert', (data) => {
           toastr.success(data.message);
           console.log(data);
        });

        $('#summernote').summernote({
            placeholder: 'Write event description here...'
        });

        $(".flatpickr2").flatpickr({
            enableTime: true,
            dateFormat: "Y-m-d H:i",
        });

        $(".flatpickr1").flatpickr({
            enableTime: true,
            dateFormat: "Y-m-d H:i",
        });
    });


</script>



<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script>toastr.error('<?php echo e($error); ?>')</script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>


<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Attendance System/AttendanceSystem/resources/views/partials/footer.blade.php ENDPATH**/ ?>