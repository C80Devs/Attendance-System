<?php if($paginator->hasPages()): ?>
<nav role="navigation" aria-label="Pagination Navigation" class="flex justify-between">
    
    <?php if($paginator->onFirstPage()): ?>
    <span
        class="cursor-not-allowed relative inline-flex items-center px-2 py-1 text-sm font-medium text-gray-500 bg-white border border-gray-300 cursor-default leading-5 rounded-md">
                <?php echo __('pagination.previous'); ?>

            </span>
    <?php else: ?>
    <a href="<?php echo e($paginator->previousPageUrl()); ?>"
       class="relative inline-flex items-center px-2 py-1 text-sm font-medium text-gray-500 bg-white border border-gray-300 leading-5 rounded-md hover:text-gray-400 focus:outline-none focus:border-blue-300 focus:shadow-outline-blue active:bg-gray-100 active:text-gray-500 transition ease-in-out duration-150">
        <?php echo __('pagination.previous'); ?>

    </a>
    <?php endif; ?>

    
    <?php if($paginator->hasMorePages()): ?>
    <a href="<?php echo e($paginator->nextPageUrl()); ?>"
       class="relative inline-flex items-center px-2 py-1 text-sm font-medium text-gray-500 bg-white border border-gray-300 leading-5 rounded-md hover:text-gray-400 focus:outline-none focus:border-blue-300 focus:shadow-outline-blue active:bg-gray-100 active:text-gray-500 transition ease-in-out duration-150">
        <?php echo __('pagination.next'); ?>

    </a>
    <?php else: ?>
    <span
        class="cursor-not-allowed relative inline-flex items-center px-2 py-1 text-sm font-medium text-gray-500 bg-white border border-gray-300 cursor-default leading-5 rounded-md">
                <?php echo __('pagination.next'); ?>

            </span>
    <?php endif; ?>
</nav>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Attendance System/AttendanceSystem/resources/views/vendor/tailwind.blade.php ENDPATH**/ ?>